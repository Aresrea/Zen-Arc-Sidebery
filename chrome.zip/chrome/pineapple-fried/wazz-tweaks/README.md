# Wazz styles
My own tweaks to Zen browser that aren't apart of Cohesion or Natsumi-Tweaks.

## Install and Config
- Drop the wazz-tweaks folder into your **chrome** folder
- Add `@import "wazz-tweaks/wazz-tweaks.css";` to the top of your userChrome.css file

### Add these options in `about:config`

- `zen.workspaces.show-workspace-indicator` = `false`
