# Better Active Tab Indicator

Adds a bright line next to the active tab to better highlight it.
