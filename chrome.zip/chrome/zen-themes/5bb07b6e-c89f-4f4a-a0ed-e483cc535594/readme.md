Customize the menu button. Default is the browser icon. You can customize it with URL or BASE64.
