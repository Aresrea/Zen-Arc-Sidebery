
# Add new tab urlbar icon
Adds an icon and the text "open in new tab" to the urlbar when it is opened by pressing the "New Tab" button or by pressing "Ctrl+T" so that it is easy to differentiate between when you are editing a URL and opening a new tab.
