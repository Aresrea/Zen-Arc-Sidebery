Enhanced tab preview, which matches browser background color.

Also adds padding around tab preview image, to synergize with the rest of the browser.
For now, mostly just styles it differently, later some customization is planned.

For bugs and discussion, go to project github.

Works as of `1.0.2-b.2`
