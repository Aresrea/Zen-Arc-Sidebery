
Make the Zen Browser's background transparent allowing the system blur to come through. 
This will utilize the browser.tabs.allow_transparent_browser flag in about:config to enable transparency. You can use the ["Zen Internet"](https://addons.mozilla.org/en-US/firefox/addon/zen-internet/) firefox addon to get website transparency. 

Enjoy <3