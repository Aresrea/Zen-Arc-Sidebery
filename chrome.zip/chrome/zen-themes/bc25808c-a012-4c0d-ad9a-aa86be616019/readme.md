semi-transparent borders for a modern, minimalist look
