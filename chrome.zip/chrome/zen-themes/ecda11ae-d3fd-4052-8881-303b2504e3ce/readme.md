# Gruvbox theme for Zen Browser

This is a Gruvbox theme for Zen Browser. It is based on the Gruvbox theme for Vim. It is a dark theme with a retro feel. It is designed to be easy on the eyes and to be easy to read.
