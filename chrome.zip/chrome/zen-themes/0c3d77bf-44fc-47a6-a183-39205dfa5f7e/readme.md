# Hidden Reset Button

Hide the reset button behind the tab icon unless hovered.
