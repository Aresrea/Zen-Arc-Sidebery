Show pinned tab's reset button only on hover, even on the active tab.
Zen browser always show the reset button on the active pinned tab by default, and this theme will disable that behavior and make reset button on the active pinned tab only visible on hover.
