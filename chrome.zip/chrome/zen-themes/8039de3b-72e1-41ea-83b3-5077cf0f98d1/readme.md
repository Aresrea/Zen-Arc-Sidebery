
made it for an extra animation when using a trackpad.
