
# Zen Mod: Tab title fixes

Increase size of tab titles and add make pending tabs standing out more.

![screenshot](./tab-title-fix.png)

[Source code at GitHub](https://github.com/psu/zen-mods)
