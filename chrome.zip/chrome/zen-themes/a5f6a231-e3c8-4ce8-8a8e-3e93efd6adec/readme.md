# Zen Cleaned URL Bar

Cleans up zen's URL bar. Current customization:
- The URL panel's color
- The URL panel's transparency
- The URL selected's color
- The URL selected's font color
