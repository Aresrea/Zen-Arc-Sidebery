With this theme you can make the compact mode even more compact!

This theme makes two changes:

- It reduces the height of the tab sidebar while in compact mode
- It reduces the minimum width of the tab sidebar

This theme works well with the **Minimal Sidebar** theme
