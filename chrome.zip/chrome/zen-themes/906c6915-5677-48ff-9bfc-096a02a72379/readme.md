# Zen Floating Statusbar

Mod for Zen Browser that detaches the status bar from the bottom left corner of the browser window so that it appears to float.
