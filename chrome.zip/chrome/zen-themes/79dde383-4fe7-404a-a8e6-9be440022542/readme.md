
# Zen Tidy Popup
Modifies popup panels, changing divider lines with empty spacer, and makes the button more compact.

There is an option for custom hover color for the buttons. You need to check the box and enter the custom color in rgba, hsla, or hex format.
