
The mod changes the pop-ups to more aesthetically pleasing ones.
