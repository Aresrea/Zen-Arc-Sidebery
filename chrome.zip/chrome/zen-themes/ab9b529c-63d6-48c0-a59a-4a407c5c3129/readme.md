# Zen Minimal Sidebar Theme

With this theme, you can hide the buttons in the sidebar and make it minimalistic.

The following buttons can be hidden:

- All tabs button
- New tab button
- Profile button
- Bookmarks button
- History button
- Preference button
- Sidepanel button
- Expand sidebar button (outdated - can be removed in the Look and Feel settings)
