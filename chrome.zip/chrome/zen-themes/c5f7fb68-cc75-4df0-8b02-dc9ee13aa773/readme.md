# Audio Tab Icon Plus

Enhance the visibility of the audio/mute tab icon. Furthermore, it allows the icon to be displayed even if the tab is not focused and/or suspended.
