# Zen Paper Cut Theme

Zen's interface be made pointy and boxy. Watchout for paper cuts!
