# NavBar Margin

Adds some top- and bottom-margin to the navbar so it doesn't look too tight.
