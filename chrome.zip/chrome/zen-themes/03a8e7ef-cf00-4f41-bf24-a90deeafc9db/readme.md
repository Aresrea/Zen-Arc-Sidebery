
# Zen "Colored" picker

Get back the sweet rainbow in your color picker [Zen Browser](https://zen-browser.app/).
Know your colors better with Zen "Colored" picker

---

Thumbnail

![image](https://raw.githubusercontent.com/Nimit1705/zen-colored-picker/refs/heads/main/Mod-thumbnail.png)

---

You can find the code of the mod inside this repository!
