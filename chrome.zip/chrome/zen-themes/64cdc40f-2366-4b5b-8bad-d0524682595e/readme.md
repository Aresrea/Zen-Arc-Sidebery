# Allow Toolbar Theming

This allows you to use Firefox themes to customize your toolbar in Zen browser. This is useful if you want to use firefox themes to customize your toolbar in Zen browser.

> ⚠️ This does not work for every theme! Please report any issues you encounter.
