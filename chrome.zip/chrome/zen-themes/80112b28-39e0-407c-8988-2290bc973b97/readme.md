Sweet peaceful theme based on green tea aesthetics, supported all Zen theming mode (Light, Dark, Zen Dream and Zen Galaxy).

[Star the repo](https://github.com/KiKaraage/ZenMods) if you appreciate this theme!
