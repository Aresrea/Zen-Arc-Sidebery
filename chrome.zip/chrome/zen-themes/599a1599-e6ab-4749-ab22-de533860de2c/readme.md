
My collection of improvements to PiP inspired by we know which browser. Greatly improves look and feel.
