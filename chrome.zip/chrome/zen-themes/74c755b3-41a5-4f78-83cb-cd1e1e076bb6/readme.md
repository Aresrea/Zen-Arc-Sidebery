# Better UniExtBtn

The unified extension button does not match the color of other extension buttons. It looks more comfortable to change it to the browser icon.

v1.0.1 2024-12-04
Added official Firefox icon and customization options
