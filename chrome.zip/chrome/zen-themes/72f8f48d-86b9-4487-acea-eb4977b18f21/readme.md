
# Zen Mod: Better CtrlTab Panel

Re-style and add customization options for the CtrlTab panel.

![screenshot](./better-ctrltab-panel.png)

[Source code at GitHub](https://github.com/psu/zen-mods)
