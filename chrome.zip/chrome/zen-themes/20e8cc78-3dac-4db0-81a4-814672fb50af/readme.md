
# Zen Mod: Right Side Glance Buttons

Move the at a glance buttons to the right side of the window.

![screenshot](./glance-buttons-right.png)

[Source code at GitHub](https://github.com/psu/zen-mods)
