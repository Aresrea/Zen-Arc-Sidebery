
# Zen Better Spacing

Let Zen breathe with this mod that adds the following changes:

- More margin on the URL bar for two toolbars setting.
- Sidebar icons aligned with the browser window.
